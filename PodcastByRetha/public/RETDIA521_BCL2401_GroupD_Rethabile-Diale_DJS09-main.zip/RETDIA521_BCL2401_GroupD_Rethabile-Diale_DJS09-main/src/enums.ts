export enum Permissions {
  ADMIN = "ADMIN",
  READ_ONLY = "READ_ONLY",
}

export enum LoyaltyUser {
  GOLD_USER = "GOLD_USER",
  SILVER_USER = "SILVER_USER",
  BRONZE_USER = "BRONZE_USER",
}
