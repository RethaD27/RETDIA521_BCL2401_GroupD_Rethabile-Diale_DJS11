export type Price = 25 | 30 | 35 | 45;
export type Country = "Colombia" | "Poland" | "United Kingdom" | "Malaysia";
